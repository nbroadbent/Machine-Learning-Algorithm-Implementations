﻿# Folders to be copied
$MyDirs = "\Contacts", "\Desktop", "\Documents", "\Downloads", "\Favorites", "\Links", "\Music", "\Pictures", "\Saved Games", "\Videos"

# Copy folders to OneDrive
Foreach ($dir in $MyDirs)
{
    Robocopy ($env:HOMEPATH+$dir) ($env:OneDrive +$dir) /MIR /R:5 /MT:32
}