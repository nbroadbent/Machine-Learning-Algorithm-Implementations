﻿function clt ($x, $mean, $std, $n) {
    return ($x - $mean) / ($std / [Math]::Sqrt($n))
}

function mean ($x, $p) {
    $mean = 0
    for ($i = 0; $i -lt $x.Count; $i++) {
        $mean += $x[$i] * $p[$i]
    }
    return $mean
}

function variance ($x, $mean) {
    $var = 0
    for ($i = 0; $i -lt $x.Count; $i++) {
        $var += ($x[$i] - $mean) * ($x[$i] - $mean)
    }
    return $var
}

function sum ($x) {
    $s = 0
    foreach ($num in $x) {
        $s += $num
    }
    return $s
}

# List of paper values
$paper = @(-4)*5 + @(4)*5 + @(-3)*4 + @(3)*4 + @(-2)*3 + @(2)*3 + @(-1)*2 + @(0)*2 + @(1)*2

# Paper probability distribution
$x = -4, -3, -2, -1, 0, 1, 2, 3, 4
$dis = (5/30), (4/30), (3/30), (2/30), (2/30), (2/30), (3/30), (4/30), (5/30)

# Calculate mean and variance
$mean = mean $x $dis
$var = variance $x $mean

Write-Host "A. Probability Distribution:"
Write-Host "Values:" $x
Write-Host "Respective distribution:" $dis
Write-Host "Mean: " $mean "  Variance:" $var

# B. Draw 50 samples of size 10
$samples = @(0) * 50
for ($i = 0; $i -lt 50; $i++) {
    $s = @(0) * 10
    $map =@(0) * 30
    for ($j = 0; $j -lt 10; $j++) {
        # No replacement
        $num = 0
        do {
            $num = Get-Random -Minimum 0 -Maximum $paper.Count
        } while ($map[$num] -eq 1)

        $s[$j] = $paper[$num]
        $map[$num] = 1
    }
    # Add sample
    $samples[$i] = @($s)
}

# C. Calculate mean and variance of samples
$vars = @(0) * 50
$means = @(0) * 50
for ($i = 0; $i -lt 50; $i++) {
    $means[$i] = sum $samples[$i]
    $means[$i] = ($means[$i] / $samples[$i].Count)

    $vars[$i] = variance $samples[$i] $means[$i]
    Write-Host ($i+1) "  Mean:" $means[$i] "  Variance:" $vars[$i]
}

# D. CLT
$z = @(0) * 50
$n = $means.Count
$std = [Math]::Sqrt($var)
for ($i = 0; $i -lt 50; $i++) {
    $z[$i] = clt $means[$i] $mean $var $std $n
    Write-Host "z:" $z[$i] 
}