﻿# Read file
$files = Get-ChildItem "\\Network:"
Write-Host $files