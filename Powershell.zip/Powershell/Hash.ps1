﻿class column {
    # Character and it's position in a word
    $pos = 0
    $char = 'A'


}

class PowerHash {
    $alpha = @('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')

    [String] hashToNum($origHash) {
        $hash = @(0) * $origHash.Length
        for ($i = 0; $i -lt $origHash.Length; $i++) {
            for ($a = 0; $a -lt $this.alpha.Count; $a++) {
                #Write-Host $fileHash.Hash[$i] $alpha[$a]
                if ($origHash[$i] -eq $this.alpha[$a]) {
                    $hash[$i] = $a
                    break
                } else {
                    $hash[$i] = $origHash[$i]
                }
            }
        }
        return [system.String]::Join("", $hash)
    }

    PowerHash() {
        

        #$diff = $hash.Hash - $hash1.Hash
        #Write-Host $diff
    }

    [String] stringHash([String] $String, $HashName = "SHA256") 
    { 
        $StringBuilder = New-Object System.Text.StringBuilder 
        [System.Security.Cryptography.HashAlgorithm]::Create($HashName).ComputeHash([System.Text.Encoding]::UTF8.GetBytes($String))|%{ 
        [Void]$StringBuilder.Append($_.ToString("x2")) 
        } 
        return $StringBuilder.ToString() 
    }

    [float] error($realHash, $fakeHash) {
        $error = $this.hashToNum($realHash) - $this.hashToNum($fakeHash)
        Write-Host 'Error: ' $error -BackgroundColor Red
        return $error
        # Calculate error w.r.t char
        #for ($i = 0; $i -lt $text.length; $i++) {
       #     $charHash = $this.stringHash($text[$i], 'SHA256')
       #     Write-Host $i $charHash
       # }
    }

    attackFile($origPath) {
        $fakePath = 'C:\Users\nbroadbent\Documents\fake.txt'
        # Generate original file hash.
        $realHash = Get-FileHash $origPath -Algorithm SHA256
        # Generate starting input.
        $text = "test"
        $text | Out-File $fakePath

        for ($i = 0; $i -lt 100; $i++) {
            # Generate fake file hash.
            $fakeHash = Get-FileHash $fakePath -Algorithm SHA256
            # Calculate error.
            $error = $this.error($realHash.Hash, $fakeHash.Hash)
            # Reduce error
            $min = 0
            for ($i = 0; $i -lt $this.alpha.length; $i++) {
                $c = $this.error($realHash.Hash, $this.stringHash($this.alpha[$i], 'SHA256')) 
                #Write-Host $c
                if ($c -gt $min) {
                    $min = $c
                }
            }

            $text = $text + $min
            $text | Out-File $fakePath
        }
    }

    findPassword ($hash, $maxLen) {
        # Generate starting input.
        $text = "AAAA"

        for ($i = $maxLen-1; $i -ge 0; $i--) {
            for ($j = 0; $j -lt $this.alpha.length; $j++) {
                # Generate hash
                if ($this.stringHash($text, "SHA256") -eq $hash) {
                    Write-Host 'The password is ' $text
                    break
                } 

                $text = $text.remove($maxLen-1, 1).insert($maxLen-1, $this.alpha[$j])
                Write-Host $text
            }
        }
    }
}

$path = 'C:\Users\nbroadbent\Documents\Test.txt'
$fileHash1 = Get-FileHash $path -Algorithm SHA256

$ph = [PowerHash]::new()
$hash1 = $ph.hashToNum($fileHash1.Hash)
Write-Host 'File1' $fileHash1.Hash
Write-Host $hash1 -BackgroundColor DarkGreen

#$ph.attackFile($path)
cls
$ph.findPassword($ph.stringHash('AABB', "SHA256"), 4)