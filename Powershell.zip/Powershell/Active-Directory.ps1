﻿Import-Module ActiveDirectory 
get-command -module ActiveDirectory

Get-ADUser nbroadbent


$new=Read-Host "Enter the new password" -AsSecureString
Set-ADAccountPassword nbroadbent -NewPassword $new