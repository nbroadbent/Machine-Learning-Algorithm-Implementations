﻿# Copy most recent backup to this pc
Robocopy ("\\hqms03\CommServeDR\SET_2116") ("G:\Commvault") /MIR /R:5 /MT:32