﻿Add-PSSnapin CloudBerryLab.Explorer.PSSnapIn

$endpoint = "s3.britesky.ca"
$key = "9WI40GYDJH0HD1JP40OO"
$secret = "RLsfAzScdWddKrAi4tdvkai/TPaUj6Zar44rnyIx"
$bucket = "A159_CV01"

# Get all files in DR directory
$files = Get-ChildItem -Path \\hqms03\CommServeDR -ErrorAction SilentlyContinue -Force

# Set is name of backup folder, highest number's the most recent backup
$max = 0
$folder = ""
for ($i = 0; $i -lt $files.Count; $i++) {
    $f = $files[$i].BaseName.split("_")
    
    if ($f[0] -eq "SET" -and $f[1] -gt $max) {
        $folder = $files[$i].BaseName 
        $max = $f[1]
    }
}

Write-Host $folder
$files = Get-ChildItem -Path ("\\hqms03\CommServeDR\" + $folder) -ErrorAction SilentlyContinue -Force
Write-Host $files

# Connecting to cloud
Set-CloudOption -ProxyPort 8080 -ProxyAuto $true
$s3 = Get-CloudS3Connection -Endpoint $endpoint -Key $key -Secret $secret
$destination = $s3 | Select-CloudFolder -path "A159_CV01/CommserveDR"


$src = Get-CloudFilesystemConnection | Select-CloudFolder ("\\hqms03\CommServeDR\" + $folder) 

#foreach ($file in $files) {
    $src | Copy-CloudItem $destination -Filter "*"
#}