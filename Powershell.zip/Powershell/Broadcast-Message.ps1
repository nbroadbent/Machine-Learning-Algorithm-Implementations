﻿# Get message input
[void][Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')
$title = 'Broadcast Message'
$desc   = 'Message:'
$msg = [Microsoft.VisualBasic.Interaction]::InputBox($desc, $title)

# Send Message 10.0.0.0/8, 

msg console /server:505131D $msg