﻿class Layer {

}

class PowerCNN {

    buildFeatureMap($kernel, $map) {
        
    }
    
    [double] pool($features, $method) {
        <# Max pooling
        for ($i = 0; $i -lt $features.Count; $i++) {
            for ($j = 0; $j -lt $features[$i].Count; $j++) {
                
            }
        }#>

        return ($features | Measure -Max).Maximum
    }

    ## Public Methods ##

    train($data, $epochs, $kNum, $k, $p, $s) {
        # 1. Convolved data

        # Initialize Kernel
        $kernel = @(0) * $k
        for ($i = 0; $i -lt $kernel.Count; $i++) {
            $kernel[$i] = @(0)*$k

        }


        for ($i = 0; $i -lt $data.Count; $i++) {
            for ($j = 0; $j -lt $data[$i].Count; $j++) {
                
            }
        }
        
        # 2. Pool Data
        
        # 3. Linearize Data
        
        # 4. Normalize Data
        
        # 5. Forward propagation
        
        # 6. Backpropagation  
    }
}