﻿Import-Module $env:HOMEPATH\documents\code\powershell\PowerSOM.ps1

#$som = Import-Clixml $env:HOMEPATH\documents\Code\Powershell\bloodSOM.xml

# Read Image
[System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
$image = [System.Drawing.Image]::FromFile('C:\Users\nbroadbent\Pictures\Blood Cells\BloodImage_00000.jpg')
$clusteredPic = New-Object System.Drawing.Bitmap(640, 480)

write-host "Reading Picture"
$count = 0
$data = @(0) * $image.Height*$image.Width
$pixelMap = @(0) * $image.Height
for ($i = 0; $i -lt $image.Height; $i++)
{
    $row = @(0) * $image.Width
    for ($j = 0; $j -lt $image.Width; $j++)
    {
        $pixel = @($image.GetPixel($j, $i).R, $image.GetPixel($j, $i).G, $image.GetPixel($j, $i).B)
        $row[$j] = $pixel
        $data[$count++] = $pixel
        #Write-Host "i:" $i " j:" $j " r:" $pixel[0] " g:" $pixel[1] " b:" $pixel[2]
        
    }
    #Write-Host "i:" $i  "row:" $row
    $pixelMap[$i] = $row
}

#write-host "Writing Picture"
#Write-Host "pm:" $pixelMap[0][400]  "data:" $data[400]


$som = [PowerSOM]::new(640, 480, 1, 0.5)
Write-Host "Normalizing"
$data = $som.normalizeData($data)

<#
$som = [PowerSOM]::new($som)
$map = $som.mapData($data)

for ($i = 0; $i -lt $som.x; $i++)
{
    $row = @(0) * $som.y
    for ($j = 0; $j -lt $som.y; $j++)
    {
        $pixel = $map[$i, $j].getWeight()
        #$row[$j] = $pixel
        $clusteredPic.SetPixel($i, $j, [System.Drawing.Color]::FromArgb($pixel[0], $pixel[1], $pixel[2]))
        Write-Host "i:" $i " j:" $j " r:" $pixel[0] " g:" $pixel[1] " b:" $pixel[2]
        
    }
    #Write-Host "i:" $i  "row:" $row
}

Write-Host "Saving bitmap"
$bmp.Save($env:HOMEPATH + "\Pictures")
#>


# Time training
Write-Host "Training"
$stopwatch = New-Object System.Diagnostics.Stopwatch
$stopwatch.Start()
$som.train($data, 1)
$stopwatch.Stop()
$stopwatch

# Store model
Write-Host "Storing"
$som | Export-Clixml $env:HOMEPATH\documents\Code\Powershell\bloodSOM.xml

# Create picture
Write-Host "Creating Bitmap"
$map = $som.getMap()
for ($i = 0; $i -lt $som.x; $i++)
{
    $row = @(0) * $som.y
    for ($j = 0; $j -lt $som.y; $j++)
    {
        $pixel = $map[$i, $j].getWeight()
        #$row[$j] = $pixel
        $clusteredPic.SetPixel($i, $j, [System.Drawing.Color]::FromArgb($pixel[0], $pixel[1], $pixel[2]))
        Write-Host "i:" $i " j:" $j " r:" $pixel[0] " g:" $pixel[1] " b:" $pixel[2]
        
    }
    #Write-Host "i:" $i  "row:" $row
}

Write-Host "Saving bitmap"
$bmp.Save($env:HOMEPATH + "\Pictures")