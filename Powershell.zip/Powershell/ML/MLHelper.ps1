﻿class MLHelper {
    $magnitudes = @()

    [double] mean($x) {
        $mean = 0
        for ($i = 0; $i -lt $x.Count; $i++) {
            $mean += $x[$i]
        }
        return ($mean / $x.Count)
    }

    [double] mean($x, $p) {
        $mean = 0
        for ($i = 0; $i -lt $x.Count; $i++) {
            $mean += $x[$i] * $p[$i]
        }
        return $mean
    }

    [double] std($x, $mean) {
        return [Math]::Sqrt($this.variance($x, $mean))
    }

    [double] variance ($x, $mean) {
        $var = 0
        for ($i = 0; $i -lt $x.Count; $i++) {
            $var += ($x[$i] - $mean) * ($x[$i] - $mean)
        }
        return $var
    }

    [object] normalizeZ($data) {
        $mean = $this.mean($data)
        $std = $this.std($data, $mean)

        for ($i = 0; $i -lt $data.Count; $i++) {
            # Standardize Data
            $data[$i] = ($data[$i] - $mean) / $std
        }
        return $data
    }

    [object] denormalizeZ($data, $mean, $var) {
        $std = [Math]::Sqrt($var)

        for ($i = 0; $i -lt $data.Count; $i++) {
            $data[$i] = ($data[$i] * $std) + $mean
        }
        return $data
    }

    [Object] normalizeUV($data) {
        # Check if 1-dimensional
        if ($data[0].Count -eq 1) {
            # Calculate vector magnitude
            for ($i = 0; $i -lt $data.Count; $i++) {
                $magnitude += [Math]::Pow($data[$i], 2)
            }
            $this.magnitudes = [Math]::Sqrt($magnitude)

            # Calculate unit vector
            for($i = 0; $i -lt $data.Count; $i++) {
                $data[$i] = $data[$i]/$this.magnitudes
            }
        } else {
            #Write-Host "x dimensional"
            for ($i = 0; $i -lt $data.Count; $i++) {
                [double] $magnitude = 0
                # Calculate vector magnitude
                for($j = 0; $j -lt $data[$i].Count; $j++) {
                    $magnitude += [Math]::Pow($data[$i][$j], 2)
                }
                $this.magnitudes += [Math]::Sqrt($magnitude)

                # Calculate unit vector
                for($j = 0; $j -lt $data[$i].Count; $j++) {
                    $data[$i][$j] = $data[$i][$j]/$this.magnitudes[$i]
                }
            }
        }
        return $data
    }

    [Object] denormalizeVector($vector, $magnitude) {
        for($i = 0; $i -lt $vector.count; $i++) {
            $vector[$i] *= $magnitude
        }
        return $vector
    }

    [Object] denormalizeUV($data) {
        for($i = 0; $i -lt $data.Count; $i++) {
            for($j = 0; $j -lt $data.Count; $j++) {
                $data[$i][$j] *= $this.magnitudes[$i]
            }
        }
        return $data
    }

    [Object] encodeLabels($data) {
        # Returns a map key: label, value: index
        Write-Host "pizza"
        $map = @{ }
        $enc = @(0) * $data.Count
        $cols = @(0) * $data[0].Count
        $mapList = @(0) * $data[0].Count
        for ($j = 0; $j -lt $data[0].Count; $j++) {
            $count = 0
            for ($i = 0; $i -lt $data.Count; $i++) {
                if ($data[$i][$j] -eq $null) {
                    $data[$i][$j] = "null"
                }

                #Write-Host $i "  d:" $data[$i][$j]
           
                if ($map.Item($data[$i][$j]) -eq $null) {
                    if (-not [string]($data[$i][$j] -as [int])) {
                        $map.Add($data[$i][$j], $count++)
                        
                        $cols[$j] = [Math]::Max($cols[$j], ($count))
 
                        #Write-Host $i $j "  d:" $data[$i][$j] "  col:" $cols[$j]
                    } else {
                        #Write-Host $i $j "  d:" $data[$i][$j] "  not string"
                    }
                }
                #Write-Host "d:" $data[$i][$j] "   m:" $map.Item($data[$i][$j])
            }

            $mapList[$j] = $map
            #Write-Host $mapList[$j].keys
            $map = @{ }
            #Write-Host $mapList[$j].keys
            #pause
        }

        for ($j = 0; $j -lt $data[0].Count; $j++) {
            for ($i = 0; $i -lt $data.Count; $i++) {
                # Skip int
                if ($cols[$j] -eq 0) {
                    continue
                }

                # Encode string
                if (-not [string]($data[$i][$j] -as [int])) { 
                    $m = $mapList[$j]
                    $val = $m.Item($data[$i][$j])
                    $data[$i][$j] = $val
                }
            }
        }

        return $data
    }
    
    [Object] oneHotEncode($data) {
        $map = $this.encodeLabels($data)
        #$vectors = New-Object 'object[,]' $data.Count, ($map.Count-1)
        # Write-Host "data2:" $data.Count "v:" $vectors.GetLength(0) $vectors.GetLength(1) "m:" $map.count
        

        # Initialize to 0, removed one column for dummy
        $vectors = ,@(,@(0) * ($map.Count -1))
        for ($i = 1; $i -lt $data.Count; $i++) {
            $vectors += ,@(,@(0) * ($map.Count -1))
           # for ($j = 0; $j -lt ($map.Count-1); $j++) {
                #$row[$j] = 0
            #}
        }
        Write-Host $vectors[0]
        Write-Host "data2:" $data.Count "v:" $vectors.count $vectors[0].count "m:" $map.count

        for ($i = 0; $i -lt $data.Count; $i++) {
            for ($j = 0; $j -lt $data[$i].Count; $j++) {
                # Set data index to 1
                if ($map.Item($data[$i][$j]) -lt $vectors[$i].Count) {
                    $vectors[$i][$map.Item($data[$i][$j])] = 1
                    #Write-Host "i: " $i " j:" $j "v:" $vectors[$i, $j] "   m:" $map.Item($data[$i][$j])
                }
            }
        }

        Write-Host $vectors[0]

        foreach($key in $map.keys) {
            
            Write-Host $map.Item($key) " k:" $key

        }

        
        for ($i = 0; $i -lt $data.Count; $i++) {
            <#$row = @()
            for ($j = 0; $j -lt $map.Count; $j++) {
                $row += $vectors[$i, $j]
            }#>

            Write-Host "i:" $i "  r:" $vectors[$i]

            
        }
        

        return $vectors
    }    

    [int] getRandomNum($range, $exclude) {
        return Get-Random -InputObject $range | Where-Object { $exclude -notcontains $_ }
    }
}

<#
$data = (1, 3, 4, 5)

$ml = [MLHelper]::new()
$ml.normalizeZ($data)
#>